# Articles

https://neo4j.com/blog/cypher-write-fast-furious/

https://community.neo4j.com/t/batch-create-and-merge-statements/20691/4



Create Unique on id
Create index

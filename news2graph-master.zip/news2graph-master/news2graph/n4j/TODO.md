
# Json Grpah
https://neo4j.com/docs/http-api/3.5/actions/return-results-in-graph-format/
https://py2neo.org/2020.0/client/http.html?highlight=http#module-py2neo.client.http


# updates
https://medium.com/neo4j/5-tips-tricks-for-fast-batched-updates-of-graph-structures-with-neo4j-and-cypher-73c7f693c8cc

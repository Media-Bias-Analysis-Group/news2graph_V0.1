#TODO

## CREATE

1. Database init
   1. create FS structure
   2. init db via neo4j import
   3. create indexes on key properties


## UPDATE

1. Get token,token_id
2. Get author_id
3. Get article_id
4. Merge on ids


## API

1. Provide Endpoints for interactions